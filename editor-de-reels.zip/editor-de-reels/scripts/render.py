#!/usr/bin/env python3
"""Renderiza o Reel final a partir do plan.json.

Faz: corte dos trechos, enquadramento vertical, b-roll opcional por trecho,
legenda animada (blocos curtos, palavras-chave em destaque), música de fundo
opcional, normalização de áudio para redes sociais (-14 LUFS), capa e .srt.

Uso:
  python render.py work/plan.json [--fontsdir pasta_com_fontes] [--preview]
"""
import argparse, json, os, re, shutil, subprocess, tempfile, unicodedata


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit("Falha no ffmpeg:\n" + " ".join(cmd) + "\n" + r.stderr[-2000:])


def ass_color(hex_):
    h = hex_.lstrip("#")
    return f"&H00{h[4:6]}{h[2:4]}{h[0:2]}&"


def ts_ass(t):
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:05.2f}"


def ts_srt(t):
    ms = int(round(t * 1000))
    return f"{ms // 3600000:02d}:{ms % 3600000 // 60000:02d}:{ms % 60000 // 1000:02d},{ms % 1000:03d}"


def key(w):
    w = unicodedata.normalize("NFKD", w.lower())
    return re.sub(r"[^a-z0-9]", "", "".join(c for c in w if not unicodedata.combining(c)))


def vfilter(o):
    W, H, F = o["width"], o["height"], o["fps"]
    return f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={F},setsar=1,format=yuv420p"


def build_captions(plan, offsets, path_ass, path_srt):
    st, o = plan["style"], plan["output"]
    hl = {key(h) for h in plan.get("highlight", [])}
    marginv = {"lower": int(o["height"] * 0.27), "middle": int(o["height"] * 0.45),
               "bottom": int(o["height"] * 0.12)}.get(st.get("position", "lower"), int(o["height"] * 0.27))
    chunks = []
    for p, off in zip(plan["pieces"], offsets):
        if p.get("no_captions"):
            continue
        words = [dict(w, s=off + max(0, w["s"] - p["start"]), e=off + min(p["end"], w["e"]) - p["start"])
                 for w in p["words"]]
        cur = []
        for i, w in enumerate(words):
            cur.append(w)
            gap = words[i + 1]["s"] - w["e"] if i + 1 < len(words) else 9
            if len(cur) >= st.get("words_per_caption", 3) or re.search(r"[.,!?:;]$", w["w"]) or gap > 0.35:
                chunks.append(cur); cur = []
        if cur:
            chunks.append(cur)
    lines_ass, lines_srt = [], []
    for i, c in enumerate(chunks):
        t0 = c[0]["s"]
        t1 = c[-1]["e"] + 0.08
        if i + 1 < len(chunks):
            t1 = min(max(t1, t0 + 0.25), chunks[i + 1][0]["s"])
        txt_ass, txt_srt = [], []
        for w in c:
            t = w["w"].upper() if st.get("uppercase", True) else w["w"]
            txt_srt.append(t)
            if key(w["w"]) in hl:
                t = "{\\c" + ass_color(st.get("highlight_color", "#FFD400")) + "}" + t + "{\\c" + ass_color(st.get("color", "#FFFFFF")) + "}"
            txt_ass.append(t)
        pop = "{\\fscx88\\fscy88\\t(0,90,\\fscx100\\fscy100)}"
        lines_ass.append(f"Dialogue: 0,{ts_ass(t0)},{ts_ass(t1)},Cap,,0,0,0,,{pop}{' '.join(txt_ass)}")
        lines_srt.append(f"{i + 1}\n{ts_srt(t0)} --> {ts_srt(t1)}\n{' '.join(txt_srt)}\n")
    hdr = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {o['width']}
PlayResY: {o['height']}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{st.get('font', 'Arial Black')},{st.get('size', 80)},{ass_color(st.get('color', '#FFFFFF'))},&H00FFFFFF&,&H00000000&,&H64000000&,1,0,0,0,100,100,0,0,1,6,2,2,80,80,{marginv},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    open(path_ass, "w").write(hdr + "\n".join(lines_ass) + "\n")
    open(path_srt, "w").write("\n".join(lines_srt))
    return len(chunks)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("plan")
    ap.add_argument("--fontsdir", default=None)
    ap.add_argument("--preview", action="store_true", help="render rápido em 540p para revisar")
    a = ap.parse_args()
    plan = json.load(open(a.plan))
    o = dict(plan["output"])
    if a.preview:
        o.update(width=o["width"] // 2, height=o["height"] // 2)
        plan["style"]["size"] = plan["style"].get("size", 80) // 2
        plan["output"] = o
    out = o.get("file", "work/reel_final.mp4")
    if a.preview:
        out = out.replace(".mp4", "_preview.mp4")
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    vf = vfilter(o)
    crf = "28" if a.preview else "18"
    preset = "ultrafast" if a.preview else "veryfast"

    with tempfile.TemporaryDirectory() as td:
        parts, offsets, t = [], [], 0.0
        for i, p in enumerate(plan["pieces"]):
            d = round(p["end"] - p["start"], 3)
            part = os.path.join(td, f"p{i:03d}.mp4")
            cmd = ["ffmpeg", "-v", "error", "-y", "-ss", str(p["start"]), "-t", str(d), "-i", p["clip"]]
            b = p.get("broll")
            if b:  # vídeo de apoio por cima, mantendo a fala do trecho
                cmd += ["-ss", str(b.get("start", 0)), "-t", str(d), "-i", b["file"],
                        "-filter_complex", f"[1:v]{vf}[v]", "-map", "[v]", "-map", "0:a"]
            else:
                cmd += ["-vf", vf]
            cmd += ["-af", "aresample=48000,afade=t=in:d=0.02,afade=t=out:st=%.3f:d=0.03" % max(0, d - 0.03),
                    "-c:v", "libx264", "-preset", preset, "-crf", crf, "-c:a", "aac", "-b:a", "192k",
                    "-ar", "48000", "-ac", "2", part]
            run(cmd)
            parts.append(part); offsets.append(t); t += d
        lst = os.path.join(td, "list.txt")
        open(lst, "w").write("".join(f"file '{x}'\n" for x in parts))
        joined = os.path.join(td, "joined.mp4")
        run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", joined])

        base = os.path.splitext(out)[0]
        ass = os.path.join(td, "caps.ass")
        n = build_captions(plan, offsets, ass, base + ".srt")
        ass_f = "ass=" + ass.replace(":", "\\:") + (f":fontsdir={a.fontsdir}" if a.fontsdir else "")
        cmd = ["ffmpeg", "-v", "error", "-y", "-i", joined]
        m = plan.get("music")
        if m:
            cmd += ["-stream_loop", "-1", "-i", m["file"]]
            vol = m.get("volume", 0.12)
            af = (f"[1:a]volume={vol},afade=t=out:st={max(0, t - 1.5):.2f}:d=1.5[m];"
                  f"[0:a][m]amix=inputs=2:duration=first:dropout_transition=0,"
                  f"loudnorm=I=-14:TP=-1.5:LRA=11[a]")
            cmd += ["-filter_complex", f"[0:v]{ass_f}[v];{af}", "-map", "[v]", "-map", "[a]"]
        else:
            cmd += ["-vf", ass_f, "-af", "loudnorm=I=-14:TP=-1.5:LRA=11"]
        cmd += ["-c:v", "libx264", "-preset", preset, "-crf", crf, "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", out]
        run(cmd)
        cover_t = plan.get("cover_time", min(1.0, t / 2))
        run(["ffmpeg", "-v", "error", "-y", "-ss", str(cover_t), "-i", out, "-frames:v", "1", "-q:v", "2",
             base + "_capa.jpg"])
    print(f"OK -> {out}  ({t:.1f}s, {len(plan['pieces'])} trechos, {n} legendas)")
    print(f"     {base}.srt  |  {base}_capa.jpg")


if __name__ == "__main__":
    main()

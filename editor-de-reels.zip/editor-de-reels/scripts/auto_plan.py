#!/usr/bin/env python3
"""Gera um plano de edição (plan.json) a partir do transcript.json.

O plano corta silêncios e hesitações, descarta takes repetidos (mantém o último,
que normalmente é o melhor) e lista os trechos na ordem dos arquivos.
Revise e ajuste o plan.json antes de renderizar: ele é só um ponto de partida.

Uso:
  python auto_plan.py work/transcript.json --out work/plan.json [--gap 0.5] [--keep-all-takes]
"""
import argparse, difflib, json, re, unicodedata

FILLERS = {"é", "eh", "ah", "ahn", "hã", "han", "hum", "hmm", "uh", "um", "tipo", "né", "então", "assim"}


def norm(t):
    t = unicodedata.normalize("NFKD", t.lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9 ]+", " ", t).split()


def phrases(clip, gap):
    words = [w for s in clip["segments"] for w in s.get("words", [])]
    if not words:  # backend sem palavras: usa os segmentos inteiros
        for s in clip["segments"]:
            toks = s["text"].split()
            step = (s["end"] - s["start"]) / max(len(toks), 1)
            words += [{"w": t, "s": s["start"] + i * step, "e": s["start"] + (i + 1) * step}
                      for i, t in enumerate(toks)]
    out, cur = [], []
    for w in words:
        if cur and w["s"] - cur[-1]["e"] > gap:
            out.append(cur); cur = []
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("transcript")
    ap.add_argument("--out", default="work/plan.json")
    ap.add_argument("--gap", type=float, default=0.5, help="pausa (s) que separa frases")
    ap.add_argument("--pad-in", type=float, default=0.12)
    ap.add_argument("--pad-out", type=float, default=0.2)
    ap.add_argument("--keep-all-takes", action="store_true")
    a = ap.parse_args()

    tr = json.load(open(a.transcript))
    items = []
    for ci, clip in enumerate(tr["clips"]):
        for ph in phrases(clip, a.gap):
            toks = norm(" ".join(w["w"] for w in ph))
            if not toks or all(t in FILLERS for t in toks):
                continue
            items.append({"clip": ci, "words": ph, "toks": toks})

    keep = [True] * len(items)
    if not a.keep_all_takes:
        for i, it in enumerate(items):
            for j in range(i + 1, min(i + 6, len(items))):
                nxt = items[j]
                ratio = difflib.SequenceMatcher(None, it["toks"], nxt["toks"]).ratio()
                prefix = len(it["toks"]) <= len(nxt["toks"]) and nxt["toks"][:len(it["toks"])] == it["toks"]
                if ratio > 0.7 or (prefix and len(it["toks"]) >= 2):
                    keep[i] = False  # take repetido ou começo abandonado: fica o seguinte
                    break

    pieces = []
    for it, k in zip(items, keep):
        if not k:
            continue
        clip = tr["clips"][it["clip"]]
        ws = it["words"]
        start = max(0.0, ws[0]["s"] - a.pad_in)
        end = min(clip["duration"], ws[-1]["e"] + a.pad_out)
        pieces.append({"clip": clip["file"], "start": round(start, 3), "end": round(end, 3),
                       "text": " ".join(w["w"] for w in ws), "words": ws})

    plan = {
        "output": {"width": 1080, "height": 1920, "fps": 30, "file": "work/reel_final.mp4"},
        "style": {"font": "Arial Black", "size": 80, "uppercase": True, "words_per_caption": 3,
                  "position": "lower", "color": "#FFFFFF", "highlight_color": "#FFD400"},
        "highlight": [],
        "music": None,
        "pieces": pieces,
    }
    json.dump(plan, open(a.out, "w"), ensure_ascii=False, indent=1)
    dropped = len(items) - len(pieces)
    total = sum(p["end"] - p["start"] for p in pieces)
    print(f"{len(pieces)} trechos mantidos, {dropped} descartados (takes repetidos). Duração estimada: {total:.1f}s")
    for i, p in enumerate(pieces):
        print(f"  [{i}] {p['end'] - p['start']:4.1f}s  {p['text'][:90]}")
    print(f"OK -> {a.out}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Transcreve um ou mais vídeos com marcação de tempo por palavra.

Uso:
  python transcribe.py VIDEO [VIDEO ...] --out work/transcript.json [--model small] [--lang pt]

Saída (transcript.json):
  {"clips": [{"file": "...", "duration": 12.3,
              "segments": [{"start": 0.5, "end": 3.1, "text": "...",
                            "words": [{"w": "Olá", "s": 0.5, "e": 0.8}, ...]}]}]}

Backends, nesta ordem: faster-whisper (recomendado) e openai-whisper.
Instale um deles com:  pip install faster-whisper
"""
import argparse, json, os, subprocess, sys, tempfile


def duration(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                          "-of", "csv=p=0", path], capture_output=True, text=True, check=True)
    return float(out.stdout.strip())


def extract_audio(path, wav):
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", path, "-vn", "-ac", "1", "-ar", "16000", wav],
                   check=True)


def load_backend(model, device):
    try:
        from faster_whisper import WhisperModel
        m = WhisperModel(model, device=device, compute_type="int8")

        def run(wav, lang):
            segs, _ = m.transcribe(wav, language=lang, word_timestamps=True, vad_filter=True,
                                   condition_on_previous_text=False)
            res = []
            for s in segs:
                words = [{"w": w.word.strip(), "s": round(w.start, 3), "e": round(w.end, 3)}
                         for w in (s.words or []) if w.word.strip()]
                res.append({"start": round(s.start, 3), "end": round(s.end, 3),
                            "text": s.text.strip(), "words": words})
            return res
        return "faster-whisper", run
    except ImportError:
        pass
    try:
        import whisper
        m = whisper.load_model(model)

        def run(wav, lang):
            r = m.transcribe(wav, language=lang, word_timestamps=True)
            res = []
            for s in r["segments"]:
                words = [{"w": w["word"].strip(), "s": round(w["start"], 3), "e": round(w["end"], 3)}
                         for w in s.get("words", []) if w["word"].strip()]
                res.append({"start": round(s["start"], 3), "end": round(s["end"], 3),
                            "text": s["text"].strip(), "words": words})
            return res
        return "openai-whisper", run
    except ImportError:
        sys.exit("Nenhum backend de transcrição encontrado. Rode: pip install faster-whisper")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("videos", nargs="+")
    ap.add_argument("--out", default="work/transcript.json")
    ap.add_argument("--model", default="small", help="tiny, base, small, medium, large-v3")
    ap.add_argument("--lang", default="pt")
    ap.add_argument("--device", default="auto")
    a = ap.parse_args()

    name, run = load_backend(a.model, a.device)
    print(f"Transcrevendo com {name} ({a.model})", flush=True)
    clips = []
    with tempfile.TemporaryDirectory() as td:
        for v in sorted(a.videos):
            wav = os.path.join(td, "a.wav")
            extract_audio(v, wav)
            segs = run(wav, a.lang)
            clips.append({"file": os.path.abspath(v), "duration": round(duration(v), 3), "segments": segs})
            print(f"  {os.path.basename(v)}: {' '.join(s['text'] for s in segs)[:120]}", flush=True)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    json.dump({"clips": clips}, open(a.out, "w"), ensure_ascii=False, indent=1)
    print(f"OK -> {a.out}")


if __name__ == "__main__":
    main()

---
name: editor-de-reels
description: Edita vídeos verticais para Instagram Reels, TikTok e Shorts a partir de takes brutos gravados no celular. Transcreve a fala, escolhe os melhores takes, corta silêncios e repetições, enquadra em 9:16, coloca legenda animada com palavras-chave em destaque, b-roll, música de fundo e áudio normalizado. Use quando o usuário pedir para editar, cortar, legendar ou montar um Reel, Short ou TikTok a partir de vídeos (.mov, .mp4).
---

# Editor de Reels

Transforma takes brutos (vários arquivos curtos gravados no celular) em um Reel pronto para postar.

## Requisitos (confira antes de começar)

- `ffmpeg` e `ffprobe` instalados (`ffmpeg -version`). Se faltar: macOS `brew install ffmpeg`, Windows `winget install ffmpeg`, Linux `apt install ffmpeg`.
- Python 3.9+ e um backend de transcrição: `pip install faster-whisper` (recomendado).
- Rodar em um ambiente com acesso aos arquivos do usuário e à internet na primeira execução (para baixar o modelo de transcrição): Claude Code ou o app desktop do Claude com uma pasta conectada.

Os scripts ficam em `scripts/` dentro desta skill. Use caminhos absolutos para eles.

## Fluxo de trabalho

Siga as etapas na ordem. Mostre ao usuário o resultado de cada etapa com no máximo poucas linhas.

### 1. Entender o pedido
Pergunte só o que faltar (uma pergunta curta, com padrão sugerido):
- Quais arquivos são falas e quais são b-roll (imagens de apoio sem fala). Padrão: arquivos com fala = falas.
- Ordem das falas. Padrão: ordem dos nomes dos arquivos.
- Palavras-chave para destacar na legenda e o tom (enérgico, calmo). Se o usuário não disser, escolha 4 a 8 palavras fortes do próprio texto.

### 2. Transcrever as falas
```bash
python scripts/transcribe.py FALA1.mov FALA2.mov ... --out work/transcript.json --model small --lang pt
```
Use `--model medium` se a transcrição sair com muitos erros e houver tempo.

### 3. Montar o plano de edição
```bash
python scripts/auto_plan.py work/transcript.json --out work/plan.json
```
O script corta pausas, remove hesitações e descarta takes repetidos (mantém o último). Depois, **leia o plan.json e revise como um editor humano faria**:
- O texto final tem começo, meio e fim? Remova trechos que repetem ideia ou fogem do assunto.
- A primeira frase é o gancho. Se houver uma frase mais forte em outro take, mova-a para o início.
- Corrija no campo `words` erros de transcrição de nomes próprios e termos técnicos (eles aparecem na legenda).
- Se o vídeo passar de 60 s, proponha cortes ao usuário.
- Preencha `highlight` com as palavras-chave.
- B-roll: em trechos longos ou de explicação, adicione `"broll": {"file": "caminho/broll.mov", "start": 2.0}` ao trecho. A fala continua; só a imagem muda. Não use b-roll no primeiro trecho (o rosto segura a atenção).
- Música: `"music": {"file": "musica.mp3", "volume": 0.1}`. Avise o usuário que, para alcance, costuma ser melhor adicionar a música em alta pelo próprio Instagram.

Campos de `style`: `font` (precisa estar instalada; use `--fontsdir` para uma pasta com .ttf), `size`, `uppercase`, `words_per_caption` (2 ou 3), `position` (`lower`, `middle`, `bottom`), `color`, `highlight_color`.

### 4. Prévia rápida
```bash
python scripts/render.py work/plan.json --preview
```
Extraia 3 a 4 quadros da prévia (`ffmpeg -ss T -i prévia -frames:v 1 quadro.jpg`) e olhe você mesmo: legenda legível e fora do rosto, enquadramento sem cortar a cabeça, b-roll sem telas com informação sensível. Ajuste o plano se precisar.

### 5. Render final
```bash
python scripts/render.py work/plan.json
```
Gera `reel_final.mp4` (1080×1920, 30 fps, H.264, áudio em -14 LUFS), `reel_final.srt` e `reel_final_capa.jpg`. Entregue os três ao usuário com um resumo: duração, número de cortes e palavras destacadas.

## Boas práticas de Reels (aplique ao revisar o plano)
- Gancho nos primeiros 2 segundos, sem "oi, gente".
- Cortes secos entre frases mantêm ritmo; não deixe pausas maiores que 0,3 s.
- Legenda em blocos de 2 a 3 palavras, no terço inferior, longe da área dos botões do Instagram (lateral direita e rodapé).
- Termine com uma chamada clara (comentar, salvar, seguir).

## Problemas comuns
- **"Nenhum backend de transcrição"**: `pip install faster-whisper`.
- **Fonte não aparece**: passe `--fontsdir /pasta/com/fontes` ou troque `style.font` por uma fonte instalada.
- **Vídeo do iPhone (HEVC) lento**: é normal na primeira passada; use `--preview` para iterar.
- **Legenda dessincronizada**: o backend não retornou tempo por palavra; use faster-whisper.

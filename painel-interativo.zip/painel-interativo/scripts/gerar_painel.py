#!/usr/bin/env python3
"""Transforma uma planilha num painel interativo em um único arquivo HTML.

Uso:
  python gerar_painel.py dados.xlsx --data "Data" --valor "Receita" --dims "Região,Produto,Vendedor" \
      [--qtd "Quantidade"] [--titulo "Painel de vendas"] [--moeda "R$"] [--aba Planilha1] --out painel.html

O arquivo gerado abre em qualquer navegador, funciona offline e pode ser enviado por e-mail
ou WhatsApp. Não usa nenhuma ferramenta paga nem biblioteca externa.
"""
import argparse, json, os
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))


def load(path, aba):
    if path.lower().endswith((".xlsx", ".xlsm", ".xls")):
        return pd.read_excel(path, sheet_name=aba or 0)
    for sep in (";", ","):
        df = pd.read_csv(path, sep=sep, encoding="utf-8-sig")
        if df.shape[1] > 1:
            return df
    return df


def to_num(s):
    if not pd.api.types.is_numeric_dtype(s):
        s = s.astype(str).str.replace("R$", "", regex=False).str.strip()
        br = s.str.contains(r",\d{1,2}$", regex=True)
        s = s.where(~br, s.str.replace(".", "", regex=False).str.replace(",", ".", regex=False))
    return pd.to_numeric(s, errors="coerce")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("arquivo")
    ap.add_argument("--data", required=True)
    ap.add_argument("--valor", required=True)
    ap.add_argument("--qtd", default=None)
    ap.add_argument("--dims", default="")
    ap.add_argument("--titulo", default="Painel")
    ap.add_argument("--subtitulo", default="")
    ap.add_argument("--moeda", default="R$")
    ap.add_argument("--aba", default=None)
    ap.add_argument("--out", default="painel.html")
    a = ap.parse_args()

    df = load(a.arquivo, a.aba)
    n0 = len(df)
    df[a.data] = pd.to_datetime(df[a.data], dayfirst=True, errors="coerce")
    df[a.valor] = to_num(df[a.valor])
    if a.qtd:
        df[a.qtd] = to_num(df[a.qtd]).fillna(0)
    ruins = df[a.data].isna() | df[a.valor].isna() | (df[a.data] > pd.Timestamp.now() + pd.Timedelta(days=1))
    descartadas = int(ruins.sum())
    df = df[~ruins].copy()
    dims = [d.strip() for d in a.dims.split(",") if d.strip()]
    for d in dims:
        df[d] = df[d].fillna("(sem valor)").astype(str)

    # agrega por dia + dimensões para o arquivo ficar leve
    df["_d"] = df[a.data].dt.strftime("%Y-%m-%d")
    agg = {a.valor: "sum", "_n": "sum"}
    df["_n"] = 1
    if a.qtd:
        agg[a.qtd] = "sum"
    g = df.groupby(["_d"] + dims, dropna=False).agg(agg).reset_index()
    rows = []
    for r in g.itertuples(index=False):
        rec = list(r)
        rows.append([rec[0]] + [str(x) for x in rec[1:1 + len(dims)]] +
                    [round(float(rec[1 + len(dims)]), 2), int(rec[2 + len(dims)])] +
                    ([round(float(rec[3 + len(dims)]), 2)] if a.qtd else []))
    payload = {"titulo": a.titulo, "subtitulo": a.subtitulo, "moeda": a.moeda, "dims": dims,
               "valor": a.valor, "qtd": a.qtd, "rows": rows,
               "base": {"linhas": n0, "descartadas": descartadas},
               "gerado": pd.Timestamp.now().strftime("%d/%m/%Y %H:%M")}
    tpl = open(os.path.join(HERE, "..", "dados", "painel_template.html"), encoding="utf-8").read()
    html = tpl.replace("/*__DATA__*/null", json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
    html = html.replace("{{TITULO}}", a.titulo)
    open(a.out, "w", encoding="utf-8").write(html)
    kb = os.path.getsize(a.out) / 1024
    print(f"OK -> {a.out} ({kb:.0f} KB, {len(rows)} linhas agregadas, {descartadas} linhas descartadas)")


if __name__ == "__main__":
    main()

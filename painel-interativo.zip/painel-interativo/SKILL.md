---
name: painel-interativo
description: Transforma uma planilha (Excel ou CSV) num painel interativo em um único arquivo HTML, com indicadores, comparação com o período anterior, gráficos com filtros e detalhe ao passar o mouse, sem precisar de Power BI, Looker ou qualquer ferramenta paga. Use quando o usuário pedir um dashboard, painel, BI ou acompanhamento visual dos números de uma planilha de vendas, financeiro, operação ou marketing.
---

# Painel interativo

Gera um arquivo `.html` que abre em qualquer navegador, funciona offline e pode ser enviado por e-mail ou WhatsApp. Não usa biblioteca externa nem ferramenta paga.

O painel tem: filtros (período e cada dimensão), indicadores com variação vs período anterior, evolução diária com o período anterior sobreposto, um gráfico que explica **de onde veio** a variação, gráficos por dimensão (clicar numa barra filtra o painel) e uma tabela de detalhe. Tudo responde aos filtros. Tema claro e escuro automáticos.

Script em `scripts/` desta skill (caminho absoluto). Requisitos: Python com pandas e openpyxl (`pip install pandas openpyxl` se faltar).

## 1. Entender a planilha
Abra as primeiras linhas e os nomes das colunas. Identifique sem perguntar, se estiver claro:
- a coluna de **data** e a de **valor** (receita, custo, leads...);
- a de **quantidade**, se houver (opcional);
- até 4 **dimensões** para filtrar e quebrar (região, produto, vendedor, canal...). Prefira colunas com poucos valores distintos (até ~50).

Pergunte só o que for ambíguo, numa mensagem, com sugestão. Não use como dimensão colunas com dados pessoais (CPF, e-mail, nome de cliente).

## 2. Gerar
```bash
python scripts/gerar_painel.py PLANILHA.xlsx --data "Data" --valor "Receita" --qtd "Quantidade" \
  --dims "Região,Produto,Vendedor" --titulo "Painel de vendas" --subtitulo "Nome da empresa" --out painel.html
```
O script descarta linhas sem data/valor e datas no futuro, e informa quantas no rodapé do painel.

## 3. Conferir e entregar
- Abra o HTML no navegador (ou tire um print com um navegador headless, se disponível) e confira: números dos indicadores batem com uma soma simples da planilha, gráficos aparecem, filtros funcionam.
- Entregue o arquivo e diga em 2 a 3 linhas o que o painel mostra de mais importante (ex.: "a queda de 13,7% vem quase toda do Sul").
- Se o ambiente permitir publicar páginas (artefatos), ofereça publicar o painel para compartilhar por link.

## Atualizar
Para atualizar com dados novos, rode o mesmo comando com a planilha nova. Se o usuário quiser isso toda semana, sugira uma tarefa agendada que rode o comando e envie o arquivo.

## Limites
- Feito para até algumas centenas de milhares de linhas (os dados são agregados por dia e dimensão). Para bases maiores, agregue antes ou use um banco de dados.
- Os valores são somados. Para indicadores que não se somam (ex.: taxa de conversão), calcule numerador e denominador em colunas separadas e explique ao usuário.

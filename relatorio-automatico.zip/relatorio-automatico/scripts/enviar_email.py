#!/usr/bin/env python3
"""Envia o relatório em PDF por e-mail (SMTP).

Uso:
  python enviar_email.py relatorio/relatorio_2026-11-16.pdf --para "diretoria@empresa.com,ana@empresa.com" \
      --assunto "Relatório semanal" --corpo relatorio/resumo_email.txt

Credenciais por variáveis de ambiente (nunca no código):
  SMTP_HOST (ex.: smtp.gmail.com)  SMTP_PORT (587)  SMTP_USER  SMTP_PASS
No Gmail, SMTP_PASS é uma "senha de app" (Conta Google > Segurança > Senhas de app).
Se o Claude tiver um conector de e-mail (Gmail/Outlook), prefira o conector e não use este script.
"""
import argparse, os, smtplib, ssl
from email.message import EmailMessage


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--para", required=True)
    ap.add_argument("--assunto", required=True)
    ap.add_argument("--corpo", default=None, help="arquivo .txt com o texto do e-mail")
    a = ap.parse_args()
    host, user, pw = os.environ.get("SMTP_HOST"), os.environ.get("SMTP_USER"), os.environ.get("SMTP_PASS")
    if not (host and user and pw):
        raise SystemExit("Defina SMTP_HOST, SMTP_USER e SMTP_PASS antes de enviar.")
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = user, a.para, a.assunto
    msg.set_content(open(a.corpo, encoding="utf-8").read() if a.corpo else "Segue o relatório em anexo.")
    msg.add_attachment(open(a.pdf, "rb").read(), maintype="application", subtype="pdf", filename=os.path.basename(a.pdf))
    with smtplib.SMTP(host, int(os.environ.get("SMTP_PORT", 587))) as s:
        s.starttls(context=ssl.create_default_context()); s.login(user, pw); s.send_message(msg)
    print(f"Enviado para {a.para}")


if __name__ == "__main__":
    main()

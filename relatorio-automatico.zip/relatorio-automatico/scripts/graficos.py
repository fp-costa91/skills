"""Gráficos do relatório, seguindo boas práticas de visualização:
- uma ideia por gráfico, título que diz a conclusão
- período anterior em azul claro (mesmo tom, mais leve), atual em azul escuro
- variação em barras divergentes (azul = alta, vermelho = queda) sempre com sinal e seta
- grade só horizontal/vertical em linha fina, sem moldura, valores rotulados com parcimônia
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import pandas as pd

ATUAL, ANTERIOR = "#1c5cab", "#86b6ef"          # rampa ordinal azul (validada)
ALTA, QUEDA = "#2a78d6", "#e34948"               # par divergente azul/vermelho (validado)
INK, INK2, MUTED, GRID, BASE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9, "text.color": INK, "axes.labelcolor": INK2,
    "xtick.color": MUTED, "ytick.color": MUTED, "axes.edgecolor": BASE, "axes.titlesize": 11,
    "axes.titleweight": "bold", "axes.titlelocation": "left", "axes.titlepad": 14,
    "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
})


def br(v, casas=1, moeda="R$"):
    a = abs(v)
    if a >= 1e6:
        t = f"{a / 1e6:.{casas}f} mi"
    elif a >= 1e3:
        t = f"{a / 1e3:.{casas}f} mil"
    else:
        t = f"{a:.0f}"
    t = t.replace(".", ",")
    return f"{'−' if v < 0 else ''}{moeda} {t}".strip()


def seta(p):
    if p is None:
        return "novo"
    return f"{'▲' if p >= 0 else '▼'} {abs(p):.1f}%".replace(".", ",")


def _clean(ax, grid_axis="y"):
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.spines["bottom"].set_color(BASE)
    ax.grid(axis=grid_axis, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(length=0, pad=6)


def _save(fig, p):
    from PIL import Image
    fig.tight_layout(); fig.savefig(p); plt.close(fig)
    Image.open(p).convert("RGB").save(p)


def _subtitle(ax, txt):
    ax.text(0, 1.015, txt, transform=ax.transAxes, color=INK2, fontsize=8.5, va="bottom")


def gerar(df, cur, ant, a, m, ini, fim, ini_ant, dims):
    out, V, D = a.out, a.valor, a.data
    nome_p = "semana" if a.periodo == "semana" else "mês"
    lbl_a, lbl_p = f"Esta {nome_p}" if nome_p == "semana" else "Este mês", f"{nome_p.capitalize()} anterior"
    graficos = []

    # 1) O que explica a variação (pela 1ª dimensão)
    if dims:
        d0 = dims[0]
        rows = sorted(m["dimensoes"][d0], key=lambda r: r["atual"] - r["anterior"])
        deltas = [r["atual"] - r["anterior"] for r in rows]
        names = [r["nome"] for r in rows]
        total_delta = m["total"]["atual"] - m["total"]["anterior"]
        maior = max(rows, key=lambda r: abs(r["atual"] - r["anterior"]))
        md = maior["atual"] - maior["anterior"]
        titulo = (f"{maior['nome']} explica a maior parte da {'queda' if total_delta < 0 else 'alta'}"
                  if (md < 0) == (total_delta < 0) and abs(md) >= 0.5 * abs(total_delta)
                  else f"Variação da receita por {d0.lower()}")
        fig, ax = plt.subplots(figsize=(7.2, 0.42 * len(rows) + 1.35), dpi=200)
        ax.barh(names, deltas, height=0.55, color=[ALTA if x >= 0 else QUEDA for x in deltas])
        ax.axvline(0, color=BASE, linewidth=1)
        span = max(abs(x) for x in deltas) or 1
        for i, x in enumerate(deltas):
            ax.text(x + (span * 0.02 if x >= 0 else -span * 0.02), i, ("+" if x > 0 else "") + br(x),
                    va="center", ha="left" if x >= 0 else "right", fontsize=8.5, color=INK)
        ax.set_xlim(-span * 1.6 if min(deltas) < 0 else 0, span * 1.6 if max(deltas) > 0 else span * 0.2)
        _clean(ax, "x"); ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: br(v, 0)))
        ax.tick_params(axis="y", colors=INK, labelsize=9)
        ax.set_title(titulo, color=INK)
        _subtitle(ax, f"Diferença de receita vs {nome_p} anterior, por {d0.lower()} · total {('+' if total_delta > 0 else '') + br(total_delta)}")
        p = os.path.join(out, "grafico_1_variacao.png"); _save(fig, p)
        graficos.append(p)

    # 2) Evolução diária: atual vs anterior, alinhados por dia do período
    dc = cur.groupby(cur[D].dt.normalize())[V].sum()
    dp = ant.groupby(ant[D].dt.normalize())[V].sum()
    n = (fim - ini).days + 1
    idx_c = [ini + pd.Timedelta(days=i) for i in range(n)]
    idx_p = [ini_ant + pd.Timedelta(days=i) for i in range(n)]
    yc = [dc.get(d, 0.0) for d in idx_c]; yp = [dp.get(d, 0.0) for d in idx_p]
    if a.periodo == "semana":
        dias = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"]
        xl = [f"{dias[d.weekday()]}\n{d:%d/%m}" for d in idx_c]
    else:
        xl = [f"{d:%d}" for d in idx_c]
    fig, ax = plt.subplots(figsize=(7.2, 2.9), dpi=200)
    x = list(range(n))
    ax.plot(x, yp, color=ANTERIOR, linewidth=2, solid_capstyle="round", label=lbl_p)
    ax.plot(x, yc, color=ATUAL, linewidth=2.4, solid_capstyle="round", marker="o", markersize=4.5,
            markeredgecolor="white", markeredgewidth=1.2, label=lbl_a)
    ax.text(x[-1] + 0.15, yc[-1], lbl_a, color=INK, fontsize=8.5, va="center")
    ax.text(x[-1] + 0.15, yp[-1], lbl_p, color=INK2, fontsize=8.5, va="center")
    ax.set_xticks(x); ax.set_xticklabels(xl, fontsize=8)
    ax.set_xlim(-0.3, n - 1 + (1.9 if n <= 10 else 4))
    ax.set_ylim(0, max(yc + yp) * 1.18)
    _clean(ax, "y"); ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: br(v, 0)))
    ax.legend(loc="upper left", bbox_to_anchor=(0, 1.02), ncol=2, frameon=False, fontsize=8, handlelength=1.6)
    ax.set_title("Receita por dia", color=INK, pad=22)
    p = os.path.join(out, "grafico_2_diario.png"); _save(fig, p)
    graficos.append(p)

    # 3) Por dimensão: barra = atual, traço = anterior; rótulo com valor e variação
    for k, d in enumerate(dims, start=3):
        rows = m["dimensoes"][d][:8][::-1]
        names = [r["nome"] for r in rows]
        va_ = [r["atual"] for r in rows]; vp = [r["anterior"] for r in rows]
        fig, ax = plt.subplots(figsize=(7.2, 0.46 * len(rows) + 1.3), dpi=200)
        ax.barh(names, va_, height=0.5, color=ATUAL, label=lbl_a, zorder=2)
        ax.scatter(vp, range(len(rows)), marker="|", s=420, linewidths=2.6, color=ANTERIOR, label=lbl_p, zorder=3)
        top = max(va_ + vp) or 1
        for i, r in enumerate(rows):
            ax.text(max(r["atual"], r["anterior"]) + top * 0.02, i,
                    f"{br(r['atual'])}   {seta(r['variacao_pct'])}", va="center", fontsize=8.5, color=INK)
        ax.set_xlim(0, top * 1.42)
        _clean(ax, "x"); ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: br(v, 0)))
        ax.tick_params(axis="y", colors=INK, labelsize=9)
        ax.legend(loc="lower right", frameon=False, fontsize=8, scatterpoints=1)
        ax.set_title(f"Receita por {d.lower()}", color=INK)
        _subtitle(ax, f"Barra = {lbl_a.lower()} · traço = {lbl_p.lower()}")
        p = os.path.join(out, f"grafico_{k}_{d.lower()}.png"); _save(fig, p)
        graficos.append(p)
    return graficos

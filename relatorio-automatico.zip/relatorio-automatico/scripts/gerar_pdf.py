#!/usr/bin/env python3
"""Monta o PDF do relatório a partir de metricas.json, narrativa.md e gráficos.

Uso:
  python gerar_pdf.py relatorio/ --titulo "Relatório semanal de vendas" --empresa "Minha Empresa" [--moeda "R$"]

narrativa.md (escrito pelo Claude) aceita: títulos com '## ', parágrafos e listas com '- '.
Use **negrito** para números importantes.
"""
import argparse, glob, json, os, re
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import KeepTogether, Image, ListFlowable, ListItem, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

import matplotlib
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

_FD = os.path.join(matplotlib.get_data_path(), "fonts", "ttf")
pdfmetrics.registerFont(TTFont("Sans", os.path.join(_FD, "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("Sans-Bold", os.path.join(_FD, "DejaVuSans-Bold.ttf")))
pdfmetrics.registerFontFamily("Sans", normal="Sans", bold="Sans-Bold", italic="Sans", boldItalic="Sans-Bold")

AZUL = colors.HexColor("#1c5cab")          # cor da marca do relatório (mesma do período atual nos gráficos)
TINTA, TINTA2, MUTED = colors.HexColor("#0b0b0b"), colors.HexColor("#52514e"), colors.HexColor("#898781")
LINHA, FUNDO = colors.HexColor("#e1e0d9"), colors.HexColor("#f6f6f4")
BOM, RUIM = "#006300", "#d03b3b"           # texto de alta/queda (sempre com seta e sinal)


def money(v, moeda):
    if v is None:
        return "—"
    s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"{moeda} {s}"


def var(v, sufixo=""):
    if v is None:
        return '<font color="#898781">novo</font>'
    cor, s = (BOM, "▲") if v >= 0 else (RUIM, "▼")
    return f'<font color="{cor}">{s} {abs(v):.1f}%</font>'.replace(".", ",") + sufixo


def md(txt):
    txt = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", txt)
    return txt.replace("&", "&amp;").replace("&amp;amp;", "&amp;").replace("<b>", "<b>")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--titulo", default="Relatório de desempenho")
    ap.add_argument("--empresa", default="")
    ap.add_argument("--moeda", default="R$")
    ap.add_argument("--saida", default=None)
    a = ap.parse_args()
    m = json.load(open(os.path.join(a.pasta, "metricas.json"), encoding="utf-8"))
    narr_path = os.path.join(a.pasta, "narrativa.md")
    narr = open(narr_path, encoding="utf-8").read() if os.path.exists(narr_path) else ""

    H1 = ParagraphStyle("h1", fontName="Sans-Bold", fontSize=19, leading=23, textColor=TINTA)
    SUB = ParagraphStyle("sub", fontName="Sans", fontSize=9, textColor=TINTA2, leading=13)
    H2 = ParagraphStyle("h2", fontName="Sans-Bold", fontSize=11.5, leading=15, textColor=TINTA, spaceBefore=12, spaceAfter=5)
    P = ParagraphStyle("p", fontName="Sans", fontSize=9.5, leading=14.5, textColor=TINTA, spaceAfter=5)
    K1 = ParagraphStyle("k1", fontName="Sans", fontSize=8, textColor=TINTA2, leading=11)
    PR = ParagraphStyle("pr", fontName="Sans", fontSize=8.5, leading=11, alignment=2)
    K2 = ParagraphStyle("k2", fontName="Sans-Bold", fontSize=15, textColor=TINTA, leading=20)

    per = m["periodo"]
    fmt = lambda d: "/".join(reversed(d.split("-")))
    story = [Paragraph(a.titulo, H1),
             Paragraph(f"{a.empresa + ' · ' if a.empresa else ''}{fmt(per['inicio'])} a {fmt(per['fim'])} · comparado a "
                       f"{fmt(per['anterior_inicio'])} a {fmt(per['anterior_fim'])}", SUB), Spacer(1, 12)]
    nome_p = "semana" if per["tipo"] == "semana" else "mês"
    vs = f' <font color="#898781">vs {nome_p} anterior</font>'
    tm, tma = m["ticket_medio"]["atual"], m["ticket_medio"]["anterior"]
    tmv = round((tm - tma) / tma * 100, 1) if tm and tma else None
    rv = round((m["registros"]["atual"] - m["registros"]["anterior"]) / m["registros"]["anterior"] * 100, 1) if m["registros"]["anterior"] else None
    def compact(v):
        if v is None: return "—"
        if abs(v) >= 1e6: return f"{a.moeda} {v/1e6:.2f} mi".replace(".", ",")
        if abs(v) >= 1e4: return f"{a.moeda} {v/1e3:.1f} mil".replace(".", ",")
        return money(v, a.moeda)
    kpis = [("Receita", compact(m["total"]["atual"]), var(m["total"]["variacao_pct"], vs)),
            ("Vendas (registros)", f'{m["registros"]["atual"]:,}'.replace(",", "."), var(rv, vs)),
            ("Ticket médio", money(tm, a.moeda), var(tmv, vs))]
    if "quantidade" in m:
        kpis.append(("Itens vendidos", f'{m["quantidade"]["atual"]:,.0f}'.replace(",", "."), var(m["quantidade"]["variacao_pct"], vs)))
    cells = [[Paragraph(k, K1), Paragraph(v, K2), Paragraph(d, K1)] for k, v, d in kpis]
    t = Table([cells], colWidths=[(17.0 / len(kpis)) * cm] * len(kpis))
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), FUNDO), ("LINEABOVE", (0, 0), (-1, 0), 2, AZUL),
                           ("INNERGRID", (0, 0), (-1, -1), 6, colors.white),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 9), ("BOTTOMPADDING", (0, 0), (-1, -1), 9),
                           ("LEFTPADDING", (0, 0), (-1, -1), 10)]))
    story += [t, Spacer(1, 10)]

    bullets = []
    for line in narr.splitlines():
        line = line.rstrip()
        if line.startswith("- "):
            bullets.append(ListItem(Paragraph(md(line[2:]), P), leftIndent=10)); continue
        if bullets:
            story.append(ListFlowable(bullets, bulletType="bullet", start="•", leftIndent=12)); bullets = []
        if line.startswith("## "):
            story.append(Paragraph(md(line[3:]), H2))
        elif line.startswith("# "):
            continue
        elif line.strip():
            story.append(Paragraph(md(line), P))
    if bullets:
        story.append(ListFlowable(bullets, bulletType="bullet", start="•", leftIndent=12))

    for g in sorted(glob.glob(os.path.join(a.pasta, "grafico_*.png"))):
        from PIL import Image as PImg
        w, h = PImg.open(g).size
        story += [Spacer(1, 8), Image(g, width=16 * cm, height=16 * cm * h / w)]

    for dim, rows in m["dimensoes"].items():
        titulo_tb = Paragraph(f"Detalhe por {dim.lower()}", H2)
        data = [[dim, "Atual", "Anterior", "Variação", "Participação"]] + [
            [r["nome"], money(r["atual"], a.moeda), money(r["anterior"], a.moeda),
             Paragraph(var(r["variacao_pct"]), PR), f'{str(r["participacao_pct"]).replace(".", ",")}%'] for r in rows[:12]]
        tb = Table(data, colWidths=[5.0 * cm, 3.3 * cm, 3.3 * cm, 2.7 * cm, 2.6 * cm], repeatRows=1)
        tb.setStyle(TableStyle([("FONT", (0, 0), (-1, 0), "Sans-Bold", 8), ("FONT", (0, 1), (-1, -1), "Sans", 8.5),
                                ("TEXTCOLOR", (0, 0), (-1, 0), TINTA2), ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                                ("LINEBELOW", (0, 0), (-1, 0), 0.8, TINTA2), ("LINEBELOW", (0, 1), (-1, -1), 0.4, LINHA),
                                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
        story.append(KeepTogether([titulo_tb, tb]))
    q = m["qualidade_dos_dados"]
    story += [Spacer(1, 6), Paragraph(f"Base: {q['linhas']} linhas lidas; {q['sem_data_ou_valor']} sem data ou valor e "
                                       f"{q['datas_no_futuro']} com data no futuro foram desconsideradas. Relatório gerado automaticamente.", K1)]
    out = a.saida or os.path.join(a.pasta, f"relatorio_{per['fim']}.pdf")
    def deco(c, d):
        c.setFillColor(AZUL); c.rect(0, A4[1] - 0.18 * cm, A4[0], 0.18 * cm, stroke=0, fill=1)
        c.setFont("Sans", 7.5); c.setFillColor(MUTED)
        c.drawString(2 * cm, 1.2 * cm, a.empresa or a.titulo); c.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"Página {d.page}")
    SimpleDocTemplate(out, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.8 * cm,
                      title=a.titulo).build(story, onFirstPage=deco, onLaterPages=deco)
    print(f"OK -> {out}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Monta o PDF do relatório a partir de metricas.json, narrativa.md e gráficos.

Uso:
  python gerar_pdf.py relatorio/ --titulo "Relatório semanal de vendas" --empresa "Minha Empresa" [--moeda "R$"]

narrativa.md (escrito pelo Claude) aceita: títulos com '## ', parágrafos e listas com '- '.
Use **negrito** para números importantes.
"""
import argparse, glob, json, os, re
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import Image, ListFlowable, ListItem, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

AZUL, AMARELO, TINTA, MUTED = colors.HexColor("#1F3A93"), colors.HexColor("#F2B705"), colors.HexColor("#1B1F2A"), colors.HexColor("#6B7285")


def money(v, moeda):
    if v is None:
        return "—"
    s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"{moeda} {s}"


def var(v):
    if v is None:
        return "—"
    cor = "#1E8E5A" if v >= 0 else "#C0392B"
    return f'<font color="{cor}">{"+" if v > 0 else ""}{str(v).replace(".", ",")}%</font>'


def md(txt):
    txt = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", txt)
    return txt.replace("&", "&amp;").replace("&amp;amp;", "&amp;").replace("<b>", "<b>")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pasta")
    ap.add_argument("--titulo", default="Relatório de desempenho")
    ap.add_argument("--empresa", default="")
    ap.add_argument("--moeda", default="R$")
    ap.add_argument("--saida", default=None)
    a = ap.parse_args()
    m = json.load(open(os.path.join(a.pasta, "metricas.json"), encoding="utf-8"))
    narr_path = os.path.join(a.pasta, "narrativa.md")
    narr = open(narr_path, encoding="utf-8").read() if os.path.exists(narr_path) else ""

    H1 = ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=20, leading=24, textColor=TINTA)
    SUB = ParagraphStyle("sub", fontName="Helvetica", fontSize=10, textColor=MUTED, leading=14)
    H2 = ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=13, leading=17, textColor=AZUL, spaceBefore=10, spaceAfter=4)
    P = ParagraphStyle("p", fontName="Helvetica", fontSize=10.5, leading=15, textColor=TINTA, spaceAfter=6)
    K1 = ParagraphStyle("k1", fontName="Helvetica", fontSize=8.5, textColor=MUTED, leading=11)
    K2 = ParagraphStyle("k2", fontName="Helvetica-Bold", fontSize=15, textColor=TINTA, leading=19)

    per = m["periodo"]
    fmt = lambda d: "/".join(reversed(d.split("-")))
    story = [Paragraph(a.titulo, H1),
             Paragraph(f"{a.empresa + ' · ' if a.empresa else ''}{fmt(per['inicio'])} a {fmt(per['fim'])} · comparado a "
                       f"{fmt(per['anterior_inicio'])} a {fmt(per['anterior_fim'])}", SUB), Spacer(1, 12)]
    kpis = [("Total", money(m["total"]["atual"], a.moeda), var(m["total"]["variacao_pct"])),
            ("Registros", str(m["registros"]["atual"]), ""),
            ("Ticket médio", money(m["ticket_medio"]["atual"], a.moeda), "")]
    if "quantidade" in m:
        kpis.append(("Quantidade", f'{m["quantidade"]["atual"]:,.0f}'.replace(",", "."), var(m["quantidade"]["variacao_pct"])))
    cells = [[Paragraph(k, K1), Paragraph(v, K2), Paragraph(d, K1)] for k, v, d in kpis]
    t = Table([cells], colWidths=[(17.0 / len(kpis)) * cm] * len(kpis))
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F3F4F8")),
                           ("BOX", (0, 0), (-1, -1), 0, colors.white), ("INNERGRID", (0, 0), (-1, -1), 6, colors.white),
                           ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
    story += [t, Spacer(1, 10)]

    bullets = []
    for line in narr.splitlines():
        line = line.rstrip()
        if line.startswith("- "):
            bullets.append(ListItem(Paragraph(md(line[2:]), P), leftIndent=10)); continue
        if bullets:
            story.append(ListFlowable(bullets, bulletType="bullet", start="•", leftIndent=12)); bullets = []
        if line.startswith("## "):
            story.append(Paragraph(md(line[3:]), H2))
        elif line.startswith("# "):
            continue
        elif line.strip():
            story.append(Paragraph(md(line), P))
    if bullets:
        story.append(ListFlowable(bullets, bulletType="bullet", start="•", leftIndent=12))

    for g in sorted(glob.glob(os.path.join(a.pasta, "grafico_*.png"))):
        from PIL import Image as PImg
        w, h = PImg.open(g).size
        story += [Spacer(1, 6), Image(g, width=15 * cm, height=15 * cm * h / w)]

    for dim, rows in m["dimensoes"].items():
        story.append(Paragraph(f"Detalhe por {dim}", H2))
        data = [["", "Atual", "Anterior", "Variação", "Part."]] + [
            [r["nome"], money(r["atual"], a.moeda), money(r["anterior"], a.moeda),
             Paragraph(var(r["variacao_pct"]), P), f'{str(r["participacao_pct"]).replace(".", ",")}%'] for r in rows[:12]]
        tb = Table(data, colWidths=[5.2 * cm, 3.4 * cm, 3.4 * cm, 2.6 * cm, 2 * cm])
        tb.setStyle(TableStyle([("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 9), ("FONT", (0, 1), (-1, -1), "Helvetica", 9),
                                ("TEXTCOLOR", (0, 0), (-1, 0), MUTED), ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                                ("LINEBELOW", (0, 0), (-1, -1), 0.4, colors.HexColor("#E3E5EC")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
        story.append(tb)
    q = m["qualidade_dos_dados"]
    story += [Spacer(1, 6), Paragraph(f"Base: {q['linhas']} linhas lidas; {q['sem_data_ou_valor']} sem data ou valor e "
                                       f"{q['datas_no_futuro']} com data no futuro foram desconsideradas. Relatório gerado automaticamente.", K1)]
    out = a.saida or os.path.join(a.pasta, f"relatorio_{per['fim']}.pdf")
    def deco(c, d):
        c.setFillColor(AMARELO); c.rect(0, A4[1] - 0.25 * cm, A4[0], 0.25 * cm, stroke=0, fill=1)
        c.setFont("Helvetica", 8); c.setFillColor(MUTED); c.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"Página {d.page}")
    SimpleDocTemplate(out, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.8 * cm,
                      title=a.titulo).build(story, onFirstPage=deco, onLaterPages=deco)
    print(f"OK -> {out}")


if __name__ == "__main__":
    main()

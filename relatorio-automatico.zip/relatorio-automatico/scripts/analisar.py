#!/usr/bin/env python3
"""Calcula os indicadores de uma planilha e gera os gráficos do relatório.

Uso:
  python analisar.py dados.xlsx --data "Data" --valor "Receita" --dims "Região,Produto" \
      [--qtd "Quantidade"] [--periodo semana|mes] [--ate AAAA-MM-DD] [--aba Planilha1] --out relatorio/

Gera em --out:
  metricas.json   números do período atual vs anterior, por dimensão, destaques e alertas
  grafico_*.png   gráficos prontos para o PDF
O Claude lê o metricas.json e escreve a análise (narrativa.md) antes de gerar o PDF.
"""
import argparse, json, os
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

AZUL, AMARELO, CINZA = "#1F3A93", "#F2B705", "#9AA1B5"


def load(path, aba):
    if path.lower().endswith((".xlsx", ".xlsm", ".xls")):
        return pd.read_excel(path, sheet_name=aba or 0)
    for sep in (";", ","):
        df = pd.read_csv(path, sep=sep, encoding="utf-8-sig")
        if df.shape[1] > 1:
            return df
    return df


def to_num(s):
    if not pd.api.types.is_numeric_dtype(s):
        s = s.astype(str).str.replace("R$", "", regex=False).str.strip()
        br = s.str.contains(r",\d{1,2}$", regex=True)
        s = s.where(~br, s.str.replace(".", "", regex=False).str.replace(",", ".", regex=False))
    return pd.to_numeric(s, errors="coerce")


def pct(a, b):
    return None if not b else round((a - b) / abs(b) * 100, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("arquivo")
    ap.add_argument("--data", required=True)
    ap.add_argument("--valor", required=True)
    ap.add_argument("--qtd", default=None)
    ap.add_argument("--dims", default="")
    ap.add_argument("--periodo", default="semana", choices=["semana", "mes"])
    ap.add_argument("--ate", default=None, help="último dia do período (padrão: última data da planilha)")
    ap.add_argument("--aba", default=None)
    ap.add_argument("--out", default="relatorio")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    df = load(a.arquivo, a.aba)
    n0 = len(df)
    df[a.data] = pd.to_datetime(df[a.data], dayfirst=True, errors="coerce")
    df[a.valor] = to_num(df[a.valor])
    if a.qtd:
        df[a.qtd] = to_num(df[a.qtd])
    invalid = df[a.data].isna() | df[a.valor].isna()
    futuro = df[a.data] > pd.Timestamp.now() + pd.Timedelta(days=1)
    qualidade = {"linhas": n0, "sem_data_ou_valor": int(invalid.sum()), "datas_no_futuro": int(futuro.sum()),
                 "duplicadas": int(df.duplicated().sum())}
    df = df[~invalid & ~futuro]

    fim = pd.Timestamp(a.ate) if a.ate else df[a.data].max().normalize()
    if a.periodo == "semana":
        ini = fim - pd.Timedelta(days=6); ini_ant, fim_ant = ini - pd.Timedelta(days=7), ini - pd.Timedelta(days=1)
    else:
        ini = fim.replace(day=1); fim_ant = ini - pd.Timedelta(days=1); ini_ant = fim_ant.replace(day=1)
    cur = df[(df[a.data] >= ini) & (df[a.data] <= fim + pd.Timedelta(hours=23, minutes=59))]
    ant = df[(df[a.data] >= ini_ant) & (df[a.data] <= fim_ant + pd.Timedelta(hours=23, minutes=59))]

    tot, tot_ant = float(cur[a.valor].sum()), float(ant[a.valor].sum())
    m = {"periodo": {"tipo": a.periodo, "inicio": str(ini.date()), "fim": str(fim.date()),
                     "anterior_inicio": str(ini_ant.date()), "anterior_fim": str(fim_ant.date())},
         "qualidade_dos_dados": qualidade,
         "total": {"atual": round(tot, 2), "anterior": round(tot_ant, 2), "variacao_pct": pct(tot, tot_ant)},
         "registros": {"atual": len(cur), "anterior": len(ant)},
         "ticket_medio": {"atual": round(tot / len(cur), 2) if len(cur) else None,
                          "anterior": round(tot_ant / len(ant), 2) if len(ant) else None},
         "dimensoes": {}, "alertas": []}
    if a.qtd:
        m["quantidade"] = {"atual": float(cur[a.qtd].sum()), "anterior": float(ant[a.qtd].sum()),
                           "variacao_pct": pct(cur[a.qtd].sum(), ant[a.qtd].sum())}

    dims = [d.strip() for d in a.dims.split(",") if d.strip()]
    for d in dims:
        g = cur.groupby(d)[a.valor].sum(); ga = ant.groupby(d)[a.valor].sum()
        t = pd.DataFrame({"atual": g, "anterior": ga}).fillna(0)
        t["variacao_pct"] = [pct(x, y) for x, y in zip(t["atual"], t["anterior"])]
        t["participacao_pct"] = (t["atual"] / tot * 100).round(1) if tot else 0
        t = t.sort_values("atual", ascending=False)
        m["dimensoes"][d] = [{"nome": str(i), **{k: (round(float(v), 2) if v is not None else None) for k, v in r.items()}}
                             for i, r in t.iterrows()]
        for i, r in t.iterrows():
            if r["anterior"] > 0 and r["variacao_pct"] is not None and r["variacao_pct"] <= -20 and r["anterior"] >= 0.05 * tot_ant:
                m["alertas"].append(f"{d} '{i}' caiu {r['variacao_pct']}% vs período anterior")
            if r["anterior"] == 0 and r["atual"] > 0:
                m["alertas"].append(f"{d} '{i}' sem vendas no período anterior")
        # gráfico por dimensão
        top = t.head(8)[::-1]
        fig, ax = plt.subplots(figsize=(7, 0.45 * len(top) + 1.2), dpi=160)
        ax.barh(top.index.astype(str), top["anterior"], color=CINZA, height=0.6, label="Período anterior")
        ax.barh(top.index.astype(str), top["atual"], color=AZUL, height=0.35, label="Período atual")
        ax.spines[["top", "right"]].set_visible(False); ax.tick_params(labelsize=9)
        ax.legend(fontsize=8, frameon=False, loc="lower right"); ax.set_title(f"Por {d}", fontsize=11, loc="left")
        fig.tight_layout(); fig.savefig(os.path.join(a.out, f"grafico_{len(m['dimensoes'])}.png")); plt.close(fig)
    if qualidade["sem_data_ou_valor"] or qualidade["datas_no_futuro"]:
        m["alertas"].append(f"Qualidade: {qualidade['sem_data_ou_valor']} linhas sem data/valor e "
                            f"{qualidade['datas_no_futuro']} com data no futuro foram desconsideradas")

    # evolução diária
    d = df[(df[a.data] >= ini_ant)].groupby(df[a.data].dt.date)[a.valor].sum()
    fig, ax = plt.subplots(figsize=(7, 2.6), dpi=160)
    ax.plot(list(d.index), d.values, color=AZUL, lw=2)
    ax.axvspan(ini.date(), fim.date(), color=AMARELO, alpha=0.15, label="Período atual")
    ax.spines[["top", "right"]].set_visible(False); ax.tick_params(labelsize=8)
    ax.set_title("Evolução diária", fontsize=11, loc="left"); ax.legend(fontsize=8, frameon=False)
    fig.autofmt_xdate(); fig.tight_layout(); fig.savefig(os.path.join(a.out, "grafico_0.png")); plt.close(fig)

    json.dump(m, open(os.path.join(a.out, "metricas.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    v = m["total"]["variacao_pct"]
    print(f"Período {m['periodo']['inicio']} a {m['periodo']['fim']}: total {tot:,.2f} ({'+' if v and v > 0 else ''}{v}% vs anterior)")
    for al in m["alertas"]:
        print("  ALERTA:", al)
    print(f"OK -> {a.out}/metricas.json e gráficos")


if __name__ == "__main__":
    main()

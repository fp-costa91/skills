---
name: relatorio-automatico
description: Transforma uma planilha de vendas, financeiro ou operação (Excel ou CSV) em um relatório executivo em PDF com indicadores, comparação com o período anterior, gráficos, alertas e uma análise escrita como a de um analista, e opcionalmente envia por e-mail. Use quando o usuário pedir relatório semanal ou mensal, resumo dos números, análise de uma planilha para a diretoria ou para um cliente, ou quiser automatizar um relatório recorrente.
---

# Relatório automático

Da planilha ao PDF pronto para mandar, com uma análise que explica o que mudou e o que fazer.
Scripts em `scripts/` desta skill (caminho absoluto). Requisitos: Python com pandas, matplotlib, openpyxl e reportlab (`pip install pandas matplotlib openpyxl reportlab` se faltar).

## 1. Entender a planilha
Abra a planilha (primeiras linhas e nomes das colunas) e identifique, sem perguntar se estiver claro:
- coluna de **data**, coluna de **valor** (receita, custo...), coluna de **quantidade** (opcional)
- até 3 **dimensões** para quebrar a análise (região, produto, vendedor, canal...)
- período: **semana** (padrão) ou **mês**
Pergunte só o que for ambíguo, numa mensagem só, com sugestão. Pergunte também para quem é o relatório (diretoria, cliente, o próprio usuário): isso define o tom.

## 2. Calcular
```bash
python scripts/analisar.py PLANILHA.xlsx --data "Data" --valor "Receita" --qtd "Quantidade" --dims "Região,Produto" --periodo semana --out relatorio/
```
Gera `relatorio/metricas.json` e os gráficos. O script já descarta linhas sem data/valor e datas no futuro e registra isso em `qualidade_dos_dados`. Use `--ate AAAA-MM-DD` para fechar um período específico.

## 3. Escrever a análise (o diferencial)
Leia `metricas.json` e escreva `relatorio/narrativa.md` com três seções `##`:
1. **Resumo**: 2 a 3 frases. O número principal, a variação, e **de onde vem** a variação (decomponha: qual região/produto explica a maior parte). Ex.: "sem o Sul, as demais regiões cresceram 1,6%". Faça a conta antes de afirmar.
2. **O que chamou atenção**: 3 a 5 tópicos com números (quedas e altas relevantes, concentração, ticket médio, problemas de qualidade dos dados).
3. **Recomendações**: 2 a 3 ações práticas e específicas, ligadas aos números.

Regras: use **negrito** nos números-chave; não invente causas, sugira o que verificar; escreva em português simples, como um analista sênior falando com quem decide; nada de jargão.

## 4. Gerar o PDF
```bash
python scripts/gerar_pdf.py relatorio/ --titulo "Relatório semanal de vendas" --empresa "Nome da Empresa"
```
Converta a primeira página em imagem e confira antes de entregar (números, acentos, gráficos). Entregue o PDF com um resumo de 3 linhas.

## 5. Enviar e automatizar (opcional)
- **E-mail**: se houver conector de e-mail (Gmail/Outlook), use-o com o PDF anexado. Sem conector: `python scripts/enviar_email.py relatorio/relatorio_DATA.pdf --para "..." --assunto "..."` com SMTP_HOST, SMTP_USER e SMTP_PASS definidos como variáveis de ambiente. Sempre mostre o texto e os destinatários ao usuário e peça confirmação antes de enviar.
- **Toda semana sozinho**: se o ambiente tiver tarefas agendadas, crie uma tarefa semanal que rode as etapas 2 a 5 com a planilha atualizada. Senão, explique como agendar (cron no Mac/Linux, Agendador de Tarefas no Windows) chamando os scripts.

## Cuidados
- Planilhas com dados pessoais (CPF, nome de clientes): não copie esses campos para a análise nem para o PDF.
- Se o período atual estiver incompleto (ex.: semana em andamento), avise na análise e compare com o mesmo número de dias do período anterior.

#!/usr/bin/env python3
"""Importa extratos bancários (CSV ou OFX) para um arquivo único e padronizado.

Uso:
  python importar.py EXTRATO.csv [OUTRO.ofx ...] --base financas/

Gera/atualiza financas/transacoes.csv com as colunas:
  data (AAAA-MM-DD), descricao, valor (negativo = saída), conta, id
Transações repetidas (mesmo id) são ignoradas, então pode importar o mesmo arquivo de novo.

PDF e prints não são lidos por este script: o Claude lê o documento e grava um CSV
com as colunas data;descricao;valor, que depois é importado aqui.
"""
import argparse, csv, hashlib, io, os, re, sys
from datetime import datetime

COLS = ["data", "descricao", "valor", "conta", "id"]
DATE_KEYS = ["data", "date", "dt", "data lançamento", "data lancamento", "data movimento"]
DESC_KEYS = ["descrição", "descricao", "histórico", "historico", "lançamento", "lancamento", "description", "title", "estabelecimento", "memo"]
VAL_KEYS = ["valor", "amount", "valor (r$)", "value", "quantia"]


def parse_money(s):
    s = str(s).strip().replace("R$", "").replace(" ", "")
    neg = s.startswith("-") or s.endswith("-") or (s.startswith("(") and s.endswith(")"))
    s = s.strip("-()")
    if re.search(r",\d{1,2}$", s):          # 1.234,56
        s = s.replace(".", "").replace(",", ".")
    else:                                    # 1,234.56 ou 1234.56
        s = s.replace(",", "")
    v = float(s) if s else 0.0
    return -v if neg else v


def parse_date(s):
    s = str(s).strip()[:10]
    for f in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%y", "%Y%m%d"):
        try:
            return datetime.strptime(s, f).strftime("%Y-%m-%d")
        except ValueError:
            pass
    raise ValueError(f"data não reconhecida: {s}")


def pick(header, keys):
    h = [x.strip().lower() for x in header]
    for k in keys:
        if k in h:
            return h.index(k)
    for i, x in enumerate(h):
        if any(k in x for k in keys):
            return i
    return None


def read_csv(path, conta):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "latin-1"):
        try:
            txt = raw.decode(enc); break
        except UnicodeDecodeError:
            pass
    sample = txt[:4000]
    delim = ";" if sample.count(";") > sample.count(",") else ","
    rows = list(csv.reader(io.StringIO(txt), delimiter=delim))
    hi = next(i for i, r in enumerate(rows) if pick(r, DATE_KEYS) is not None and pick(r, VAL_KEYS) is not None)
    header = rows[hi]
    di, ci, vi = pick(header, DATE_KEYS), pick(header, DESC_KEYS), pick(header, VAL_KEYS)
    out = []
    for r in rows[hi + 1:]:
        if len(r) <= max(di, vi) or not r[di].strip():
            continue
        try:
            out.append({"data": parse_date(r[di]), "descricao": (r[ci] if ci is not None else "").strip(),
                        "valor": round(parse_money(r[vi]), 2), "conta": conta})
        except ValueError:
            continue
    return out


def read_ofx(path, conta):
    txt = open(path, "rb").read().decode("latin-1")
    out = []
    for blk in re.findall(r"<STMTTRN>(.*?)</STMTTRN>", txt, re.S | re.I):
        g = lambda t: (re.search(rf"<{t}>([^<\r\n]*)", blk, re.I) or [None, ""])[1].strip()
        out.append({"data": parse_date(g("DTPOSTED")[:8]), "descricao": g("MEMO") or g("NAME"),
                    "valor": round(parse_money(g("TRNAMT")), 2), "conta": conta, "fitid": g("FITID")})
    return out


def tx_id(t):
    base = t.get("fitid") or f"{t['data']}|{t['descricao']}|{t['valor']}|{t['conta']}"
    return hashlib.sha1(base.encode()).hexdigest()[:12]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("arquivos", nargs="+")
    ap.add_argument("--base", default="financas")
    ap.add_argument("--conta", default=None, help="nome da conta/cartão (padrão: nome do arquivo)")
    ap.add_argument("--fatura", action="store_true", help="arquivo é fatura de cartão: compras vêm positivas e viram saídas")
    a = ap.parse_args()
    os.makedirs(a.base, exist_ok=True)
    dest = os.path.join(a.base, "transacoes.csv")
    existing = list(csv.DictReader(open(dest, encoding="utf-8"))) if os.path.exists(dest) else []
    seen = {t["id"] for t in existing}
    novos = 0
    for f in a.arquivos:
        conta = a.conta or os.path.splitext(os.path.basename(f))[0]
        txs = read_ofx(f, conta) if f.lower().endswith(".ofx") else read_csv(f, conta)
        for t in txs:
            if a.fatura:
                t["valor"] = -t["valor"]
            t["id"] = tx_id(t)
            t.pop("fitid", None)
            if t["id"] in seen:
                continue
            seen.add(t["id"]); existing.append(t); novos += 1
        print(f"{os.path.basename(f)}: {len(txs)} transações lidas")
    existing.sort(key=lambda t: t["data"])
    with open(dest, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLS); w.writeheader()
        for t in existing:
            w.writerow({k: t[k] for k in COLS})
    print(f"{novos} novas transações. Total: {len(existing)} -> {dest}")


if __name__ == "__main__":
    main()

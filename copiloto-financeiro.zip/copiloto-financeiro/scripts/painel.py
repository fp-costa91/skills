#!/usr/bin/env python3
"""Gera o painel do mês (HTML) e o resumo do check-in.

Uso:
  python painel.py --base financas/ [--mes 2026-11]

Lê financas/transacoes_categorizadas.csv e financas/plano.json.
Gera financas/painel_AAAA-MM.html e imprime o resumo do check-in.
"""
import argparse, calendar, csv, html, json, os, re, unicodedata
from collections import defaultdict
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))


def brl(v):
    s = f"{abs(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return ("-R$ " if v < 0 else "R$ ") + s


def norm(s):
    s = unicodedata.normalize("NFKD", s.upper())
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"[\d*#/.-]+", " ", re.sub(r"\s+", " ", s)).strip()[:28]


def months_between(a, b):  # "2026-11" -> "2027-07"
    ya, ma = map(int, a.split("-")); yb, mb = map(int, b.split("-"))
    return (yb - ya) * 12 + (mb - ma)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="financas")
    ap.add_argument("--mes", default=None)
    ap.add_argument("--hoje", default=None, help="AAAA-MM-DD (para testes)")
    a = ap.parse_args()
    rules = json.load(open(os.path.join(a.base, "regras.json"), encoding="utf-8"))
    excl = set(rules.get("excluir_dos_gastos", []))
    plano = json.load(open(os.path.join(a.base, "plano.json"), encoding="utf-8"))
    txs = list(csv.DictReader(open(os.path.join(a.base, "transacoes_categorizadas.csv"), encoding="utf-8")))
    for t in txs:
        t["valor"] = float(t["valor"]); t["mes"] = t["data"][:7]
    meses = sorted({t["mes"] for t in txs})
    mes = a.mes or meses[-1]
    ant = meses[meses.index(mes) - 1] if mes in meses and meses.index(mes) > 0 else None
    hoje = date.fromisoformat(a.hoje) if a.hoje else date.today()
    y, m = map(int, mes.split("-"))
    dias = calendar.monthrange(y, m)[1]
    ritmo = 1.0 if (hoje.year, hoje.month) != (y, m) else hoje.day / dias

    def gastos(mm):
        g = defaultdict(float)
        for t in txs:
            if t["mes"] == mm and t["valor"] < 0 and t["categoria"] not in excl:
                g[t["categoria"]] += -t["valor"]
        return g

    g, gant = gastos(mes), (gastos(ant) if ant else {})
    receitas = sum(t["valor"] for t in txs if t["mes"] == mes and t["categoria"] == "Receitas")
    total = sum(g.values())
    aporte = sum(-t["valor"] for t in txs if t["mes"] == mes and t["categoria"] == "Metas e reservas" and t["valor"] < 0)
    orc = plano.get("orcamento", {})
    fixas = set(plano.get("categorias_fixas", ["Moradia", "Contas e serviços", "Assinaturas", "Educação", "Dívidas e tarifas"]))
    variaveis = {"Mercado", "Delivery e restaurantes", "Transporte", "Compras", "Lazer", "Revisar", "Outros"}

    linhas = []
    for cat in sorted(set(orc) | set(g), key=lambda c: -g.get(c, 0)):
        real, lim = g.get(cat, 0.0), orc.get(cat)
        if lim:
            uso = real / lim
            if cat in fixas:  # contas fixas: pagas de uma vez, só alerta se passar do orçamento
                st = "estourou" if uso > 1.02 else "ok"
            else:
                st = "estourou" if uso > 1 else ("atencao" if uso > max(0.8, ritmo + 0.1) else "ok")
        else:
            uso, st = None, ("sem_plano" if real else "ok")
        if real or lim:
            linhas.append({"cat": cat, "real": real, "lim": lim, "uso": uso, "st": st, "ant": gant.get(cat, 0.0)})

    top = sorted([t for t in txs if t["mes"] == mes and t["valor"] < 0 and t["categoria"] not in excl],
                 key=lambda t: t["valor"])[:5]
    # recorrentes: mesma descrição em 2+ meses com valor parecido
    por = defaultdict(dict)
    for t in txs:
        if t["valor"] < 0 and t["categoria"] not in excl and t["categoria"] not in variaveis:
            por[norm(t["descricao"])][t["mes"]] = -t["valor"]
    recorr = []
    for d, mv in por.items():
        vals = list(mv.values())
        if len(mv) >= 2 and mes in mv and max(vals) - min(vals) <= 0.05 * max(vals):
            recorr.append((d, mv[mes]))
    recorr.sort(key=lambda x: -x[1])

    metas = []
    for mt in plano.get("metas", []):
        falta = max(0.0, mt["valor_total"] - mt["guardado"])
        n = max(1, months_between(mes, mt["prazo"]))
        metas.append({**mt, "falta": falta, "meses": n, "por_mes": falta / n,
                      "pct": mt["guardado"] / mt["valor_total"] if mt["valor_total"] else 0})
    necessario = sum(x["por_mes"] for x in metas)

    icon = {"ok": "✅", "atencao": "⚠️", "estourou": "🚨", "sem_plano": "➖"}
    # ---------- resumo em texto ----------
    print(f"CHECK-IN {mes}  (mês {'completo' if ritmo == 1 else f'{ritmo:.0%} percorrido'})")
    print(f"Receitas {brl(receitas)} | Gastos {brl(total)} | Guardado para metas {brl(aporte)} | Saldo {brl(receitas - total - aporte)}")
    for l in linhas:
        lim = brl(l["lim"]) if l["lim"] else "sem orçamento"
        uso = f"{l['uso']:.0%}" if l["uso"] is not None else "-"
        print(f"  {icon[l['st']]} {l['cat']}: {brl(l['real'])} de {lim} ({uso})")
    print(f"Metas: precisa guardar {brl(necessario)}/mês no total; guardou {brl(aporte)} este mês")
    for x in metas:
        print(f"  {x['nome']}: {x['pct']:.0%} ({brl(x['guardado'])} de {brl(x['valor_total'])}), {brl(x['por_mes'])}/mês até {x['prazo']}")
    if recorr:
        print("Recorrentes: " + "; ".join(f"{d.title()} {brl(v)}" for d, v in recorr[:8]))

    # ---------- painel HTML ----------
    def bar(l):
        if not l["lim"]:
            return '<div class="bar"><i style="width:100%;background:var(--muted2)"></i></div>'
        w = min(100, l["uso"] * 100)
        mark = f'<b style="left:{min(100, ritmo * 100):.0f}%" title="ritmo do mês"></b>' if ritmo < 1 else ""
        return f'<div class="bar {l["st"]}"><i style="width:{w:.0f}%"></i>{mark}</div>'

    rows = "".join(
        f'<tr><td>{icon[l["st"]]} {html.escape(l["cat"])}</td><td class="n">{brl(l["real"])}</td>'
        f'<td class="n m">{brl(l["lim"]) if l["lim"] else "—"}</td><td class="b">{bar(l)}</td>'
        f'<td class="n m">{("+" if l["real"] >= l["ant"] else "") + brl(l["real"] - l["ant"]) if ant else "—"}</td></tr>'
        for l in linhas)
    mrows = "".join(
        f'<div class="meta"><div class="mh"><b>{html.escape(x["nome"])}</b><span>{x["pct"]:.0%}</span></div>'
        f'<div class="bar ok"><i style="width:{min(100, x["pct"] * 100):.0f}%"></i></div>'
        f'<small>{brl(x["guardado"])} de {brl(x["valor_total"])} · guardar {brl(x["por_mes"])}/mês até {x["prazo"]}</small></div>'
        for x in metas)
    trows = "".join(f'<li><span>{t["data"][8:]}/{t["data"][5:7]} · {html.escape(t["descricao"][:34])}</span><b>{brl(-t["valor"])}</b></li>' for t in top)
    rrows = "".join(f'<li><span>{html.escape(d.title())}</span><b>{brl(v)}</b></li>' for d, v in recorr[:8]) or "<li><span>Ainda sem histórico suficiente</span></li>"
    alerts = [l for l in linhas if l["st"] in ("estourou", "atencao")]
    alert_html = "".join(f'<li>{icon[l["st"]]} <b>{html.escape(l["cat"])}</b>: {brl(l["real"])} de {brl(l["lim"])} ({l["uso"]:.0%})</li>' for l in alerts) or "<li>✅ Tudo dentro do plano até agora.</li>"
    tpl = open(os.path.join(HERE, "..", "dados", "painel_template.html"), encoding="utf-8").read()
    out = tpl
    for k, v in {"MES": f"{calendar.month_name[m] if False else ['', 'Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'][m]} {y}",
                 "RITMO": "Mês completo" if ritmo == 1 else f"{ritmo:.0%} do mês percorrido",
                 "RECEITAS": brl(receitas), "GASTOS": brl(total), "APORTE": brl(aporte),
                 "SALDO": brl(receitas - total - aporte), "ROWS": rows, "METAS": mrows or "<p>Nenhuma meta cadastrada.</p>",
                 "TOP": trows, "RECORR": rrows, "ALERTAS": alert_html,
                 "NECESSARIO": brl(necessario), "ANT": "vs mês anterior" if ant else ""}.items():
        out = out.replace("{{" + k + "}}", v)
    dest = os.path.join(a.base, f"painel_{mes}.html")
    open(dest, "w", encoding="utf-8").write(out)
    json.dump({"mes": mes, "receitas": receitas, "gastos": total, "aporte": aporte,
               "categorias": linhas, "metas": metas}, open(os.path.join(a.base, f"resumo_{mes}.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, default=str)
    print(f"\nPainel -> {dest}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Categoriza as transações com regras que aprendem.

Uso:
  python categorizar.py --base financas/                 # aplica as regras
  python categorizar.py --base financas/ --ensinar "PADARIA DO ZE=Mercado" "UNIMED=Saúde"

As regras ficam em financas/regras.json (texto que aparece na descrição -> categoria).
Na primeira execução, o arquivo é criado a partir das regras padrão desta skill.
Transações sem regra ficam como "Revisar" e são listadas no final, agrupadas.
"""
import argparse, csv, json, os, re, shutil, unicodedata
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))


def norm(s):
    s = unicodedata.normalize("NFKD", s.upper())
    return re.sub(r"\s+", " ", "".join(c for c in s if not unicodedata.combining(c))).strip()


def load_rules(base):
    path = os.path.join(base, "regras.json")
    if not os.path.exists(path):
        shutil.copy(os.path.join(HERE, "..", "dados", "regras_padrao.json"), path)
    return path, json.load(open(path, encoding="utf-8"))


def categorize(desc, valor, rules):
    d = norm(desc)
    # regras do usuário primeiro (mais específicas), depois as padrão
    for pat, cat in sorted(rules["regras"].items(), key=lambda kv: -len(kv[0])):
        if norm(pat) in d:
            return cat
    if valor > 0:
        return "Receitas"
    return "Revisar"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="financas")
    ap.add_argument("--ensinar", nargs="*", default=[], help='"TEXTO=Categoria"')
    a = ap.parse_args()
    rpath, rules = load_rules(a.base)
    for item in a.ensinar:
        pat, cat = item.split("=", 1)
        rules["regras"][pat.strip()] = cat.strip()
        print(f"Regra aprendida: {pat.strip()} -> {cat.strip()}")
    if a.ensinar:
        json.dump(rules, open(rpath, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    src = os.path.join(a.base, "transacoes.csv")
    txs = list(csv.DictReader(open(src, encoding="utf-8")))
    for t in txs:
        t["categoria"] = categorize(t["descricao"], float(t["valor"]), rules)
    dest = os.path.join(a.base, "transacoes_categorizadas.csv")
    with open(dest, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(txs[0].keys())); w.writeheader(); w.writerows(txs)
    c = Counter(t["categoria"] for t in txs)
    print(f"{len(txs)} transações categorizadas -> {dest}")
    print("  " + " | ".join(f"{k}: {v}" for k, v in c.most_common()))
    rev = Counter(norm(t["descricao"]) for t in txs if t["categoria"] == "Revisar")
    if rev:
        print(f"\nREVISAR ({sum(rev.values())} transações sem regra). Categorias válidas: {', '.join(rules['categorias'])}")
        for d, n in rev.most_common(40):
            print(f"  {n}x  {d}")


if __name__ == "__main__":
    main()

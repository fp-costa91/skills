---
name: copiloto-financeiro
description: Copiloto de finanças pessoais. Importa extratos e faturas (CSV, OFX, PDF ou print), categoriza os gastos com regras que aprendem com o usuário, acompanha o orçamento e as metas e gera um painel mensal com alertas. Use quando o usuário mandar extrato, fatura ou lista de gastos, pedir check-in do mês, quiser montar orçamento, acompanhar metas financeiras ou simular cortes de gastos.
---

# Copiloto Financeiro

Ferramenta de **organização e educação financeira**. Nunca recomende investimentos, ativos, fundos, ações, criptomoedas ou instituições específicas. Se o usuário pedir, explique conceitos de forma geral (ex.: o que é reserva de emergência) e sugira um profissional certificado.

## Onde ficam os dados
Tudo fica numa pasta do usuário, por padrão `financas/` na pasta de trabalho:
- `transacoes.csv`: todas as transações importadas (sem duplicar)
- `regras.json`: regras de categorização (criado na primeira vez; aprende com o usuário)
- `plano.json`: renda, orçamento por categoria e metas
- `painel_AAAA-MM.html`: painel do mês

Os scripts estão em `scripts/` desta skill (use caminho absoluto). Requisitos: Python 3.9+, sem bibliotecas extras.

## Primeira vez: montar o plano
Se `financas/plano.json` não existir:
1. Pergunte, em uma mensagem só: renda mensal aproximada, gastos fixos principais e até 3 metas (o quê, quanto, até quando, quanto já tem guardado).
2. Se o usuário já mandou extratos, importe e categorize primeiro (passos abaixo) e use os gastos reais para propor o orçamento.
3. Proponha o orçamento por categoria (use 50/30/20 só como referência, ajustado à realidade dele), confirme e grave `plano.json` seguindo `dados/plano_exemplo.json`. As categorias válidas estão em `dados/regras_padrao.json`.

## Rotina: importar, categorizar, revisar, painel

**1. Importar**
- CSV ou OFX do banco: `python scripts/importar.py ARQUIVO.csv --conta "Nubank" --base financas`
- Fatura de cartão em CSV (compras positivas): acrescente `--fatura`.
- PDF ou print: leia o documento você mesmo, grave um CSV `data;descricao;valor` (saídas negativas, datas DD/MM/AAAA) e importe esse CSV. Confira com o usuário o total do documento.
- Pagamento de fatura e transferências entre contas próprias ficam na categoria "Transferências" e não contam como gasto (o gasto real é o da fatura).

**2. Categorizar**
`python scripts/categorizar.py --base financas`
O script lista o que ficou em **REVISAR**. Classifique você mesmo cada item pelo nome do estabelecimento e ensine as regras de uma vez:
`python scripts/categorizar.py --base financas --ensinar "PADARIA DO ZE=Delivery e restaurantes" "UNIMED=Saúde"`
Só pergunte ao usuário o que for realmente ambíguo (ex.: um PIX para uma pessoa). As regras ficam salvas: no mês seguinte isso já sai categorizado.

**3. Painel e check-in**
`python scripts/painel.py --base financas [--mes AAAA-MM]`
Entregue o arquivo `painel_AAAA-MM.html` ao usuário e escreva o check-in curto:
- 1 linha com receitas, gastos, guardado e saldo
- as categorias com ⚠️ e 🚨 (o painel considera o ritmo do mês: 50% do orçamento no dia 10 é alerta; contas fixas só alertam se passarem do orçamento)
- metas: quanto precisa guardar por mês vs. quanto guardou
- no máximo 3 ajustes práticos para o resto do mês, com números

## Pedidos comuns
- **"E se eu cortar X?"**: calcule o efeito no mês e no prazo das metas (ex.: cortar R$ 200/mês de delivery antecipa a meta em N meses). Mostre a conta.
- **Assinaturas**: a seção "Gastos recorrentes" do painel lista o que se repete todo mês com o mesmo valor. Pergunte quais o usuário ainda usa.
- **Atualizar meta**: edite `guardado` em `plano.json` quando o usuário informar.
- **Novo mês**: importe só o extrato novo; duplicadas são ignoradas.

## Privacidade
Lembre o usuário de não enviar senhas nem números completos de cartão ou conta. Os dados ficam só na pasta dele.
